package backEnd;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JsonParserFasad {

	private String json;

	public JsonParserFasad(String json) {
		this.json = json;
	}

	public Address parse() {
		JSONParser parser = new JSONParser();
		BuildAddressObject builder = new BuildAddressObject();
		try {
			JSONObject parsed = (JSONObject) parser.parse(json);
			builder.addAddress((String) parsed.get("address"));
			builder.addReports(((Long) parsed.get("count")).intValue());

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return builder.getResult();
	}
}
