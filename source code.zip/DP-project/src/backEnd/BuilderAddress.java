package backEnd;

public interface BuilderAddress {

	
	public void reset();
	
	public void addAddress(String addr);
	
	public void addLink();
	
	public void addReports(int reports);
	
	
	
}
