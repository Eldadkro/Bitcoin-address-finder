package backEnd;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import bitDetector.Logger;

public class BackLogic {

	private static BackLogic inst = null;
	private List<Address> addrList;
	private Logger logger;

	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger log) {
		this.logger = log;
	}

	public void closeLoger() {
		logger.close();
	}

//	public static void main(String[] args) {
//
//		BuildAddressObject b = new BuildAddressObject();
//		b.addAddress("a");
//		Address a = b.getResult();
//		System.out.println(new JSONObject().);
//	}

	private BackLogic() {
		inst = this;
		this.addrList = new ArrayList<Address>();
	}

	public static BackLogic getResource() {
		if (BackLogic.inst == null)
			inst = new BackLogic();
		return inst;
	}

	public List<Address> getAddrList() {
		return addrList;
	}

	public void removeAll() {
		addrList.clear();
	}

	public Iterator<Address> addrListIterator() {

		return addrList.iterator();

	}

	public Address saveToAddrList(String addr) {
		BuildAddressObject builder = new BuildAddressObject();
		builder.addAddress(addr);
		Address addrObject = builder.getResult();
		if (!(addrList.contains(addrObject))) {
			addrList.add(addrObject);
			return addrObject;
		}
		return null;
	}

	public void removeAddr(Address addr) {
		addrList.remove(addr);
	}

	public boolean contains(Address addr) {
		return addrList.contains(addr);
	}

	public void scanTable() {
		Iterator<Address> t;
		Address addr;
		t = addrListIterator();
		while (t.hasNext()) {

			addr = t.next();
			addr.copy(new JsonParserFasad(new ApiCallFacade(addr).callToAPI()).parse());
			BackLogic.getResource().getLogger().log("call API on address = " + addr.getAddress());
//			System.out.println(addr.toString());
		}
	}

	public void saveResults(File f) {
		if (this.addrList.isEmpty()) {
			logger.log("failed to save results, no results");
			return;
		}
		try {
			if(f.exists())
				f.delete();
			f.createNewFile();
			FileWriter file = new FileWriter(f);
			
			for (Address addr : addrList) {
				file.write("addr = "+addr.getAddress()+", link= "+addr.getLink()+", reports= "+addr.getReports()+"\n");
			}
			file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
