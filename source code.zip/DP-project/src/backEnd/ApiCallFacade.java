package backEnd;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ApiCallFacade {

	private static final String token = "Z8TKahe9FPGfyv9uwpYYv8xAZvdGwBHuebtCIkGNcydcsviM0Y77zb2pWP3A";
	private static final String baseUrl = "https://www.bitcoinabuse.com/api/reports/check/";

	private Address addr;

//	public static void main(String[] args) {
//		ApiCallFacade a = new ApiCallFacade("19TA5Sq3RP4JV2sn3UG1TNW4hRLjYKLyFx");
//		String s = a.callToAPI();
//		JsonParserFasad par = new JsonParserFasad(s);
//		Address addr = par.parse();
//		System.out.println(addr.getAddress());
//		System.out.println(addr.getReports());
//		System.out.println(addr.getLink());
//	}

	public ApiCallFacade(Address addr) {
		this.addr = addr;

	}

	public ApiCallFacade(String address) {
		BuildAddressObject builder = new BuildAddressObject();
		builder.addAddress(address);
		addr = builder.getResult();

	}

	public String callToAPI() {

		HttpURLConnection conn = null;
		try {

			StringBuilder strBuilder = new StringBuilder();
			URL url = new URL(baseUrl + "?address=" + addr.getAddress() + "&api_token=" + token);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setConnectTimeout(5000);
			conn.setReadTimeout(5000);
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				strBuilder.append(output);
			}
			return strBuilder.toString();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		} finally {
			conn.disconnect();
		}
		return null;
	}
}
