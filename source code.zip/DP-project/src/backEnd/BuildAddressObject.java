package backEnd;

public class BuildAddressObject implements BuilderAddress {

	private static final String _defaultAddr = "";
	private static final String _defaultLink = "";
	private static final int _defaultReports = 0;
	private static final String baseUrl = "https://www.bitcoinabuse.com/reports/";

	private String _addr = "";
	private String _link = "";
	private int _reports = 0;

	public BuildAddressObject() {
		reset();
	}

	@Override
	public void reset() {
		// resets to defaults
		_addr = _defaultAddr;
		_link = _defaultLink;
		_reports = _defaultReports;
	}

	@Override
	public void addAddress(String addr) {
		_addr = addr;

	}

	@Override
	public void addLink() {
		_link = Address.baseUrl + _addr;

	}

	@Override
	public void addReports(int reports) {
		_reports = reports;

	}

	public Address getResult() {
		if (_link.equals(""))
			_link = baseUrl + _addr;
		return new Address(_addr, _link, _reports);
	}

}
