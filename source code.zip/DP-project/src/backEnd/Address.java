package backEnd;

import org.json.simple.JSONObject;

public class Address {

	// class to represent data of an address

//	public static void main(String[] args) {
//		Address a = new Address("1111");
//		a.setLink("22222");
//		a.setReports(5);
//		System.out.println(a.toJson());
//	}

	public static final String baseUrl = "https://www.bitcoinabuse.com/reports/";
	private String address;
	private int reports;
	private String link;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getReports() {
		return reports;
	}

	public void setReports(int reports) {
		this.reports = reports;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = baseUrl + address;
	}

	public Address(String _address, String _link, int _reports) {
		this.address = _address;
		this.link = _link;
		this.reports = _reports;
	}

	@SuppressWarnings("unchecked")
	public String toJson() {
		JSONObject json = new JSONObject();
		json.put("address", this.address);
		json.put("reports", Integer.valueOf(this.reports));
		json.put("link", this.link);
		return json.toJSONString();
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return address.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Address)
			return address.equals(((Address) obj).address);
		return false;
	}

	@Override
	public String toString() {
		return getAddress();
	}

	public void copy(Address other) {
		this.address = other.address;
		this.link = other.link;
		this.reports = other.reports;
	}

}
