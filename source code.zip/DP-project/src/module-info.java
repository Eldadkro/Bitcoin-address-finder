module bitDetector {
	exports bitDetector;
	exports backEnd;
	exports GuiLogic;

	requires javafx.base;
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires json.simple;
	requires java.net.http;
	requires java.desktop;
	
	opens GuiLogic;
	opens backEnd;
	
}