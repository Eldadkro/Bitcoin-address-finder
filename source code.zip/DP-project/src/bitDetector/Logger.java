package bitDetector;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

import javafx.scene.control.TextArea;

public class Logger { 
	private String str;
	private FileWriter f;
	private String fileName;
	private String path;
	private TextArea logBox;
	
	
	public Logger(String fileName, String path) {
		File created = new File(path+fileName);
//		if(created.exists())
//			created.delete();
		try {
			created.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			this.f = new FileWriter(created,true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.fileName = fileName;
		this.path = path;
		System.out.println(created.getAbsolutePath());
	}
	
	public void log(String str) {
		
		//create log line
		StringBuilder builder = new StringBuilder();
		LocalDateTime timeNow = LocalDateTime.now();
		builder.append(timeNow);
		builder.append(" : ");
		builder.append(str);
		String finalLine = builder.toString();
		
		//write to the log file
		try {
			this.f.write(finalLine+"\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//update GUI
		updageTextBox(finalLine);
		
	}
	
	@SuppressWarnings("unused")
	public void setLogBox(TextArea logBox) {
		this.logBox = logBox;
	}
	
	private void updageTextBox(String str) {
		
		this.logBox.setText(str + "\n" + this.logBox.getText());
	}
	
	public void close() {
		try {
			this.f.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
