package bitDetector;

import java.io.IOException;

import GuiLogic.GuiController;
import backEnd.BackLogic;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.application.*;

public class BitDetector extends Application {

	private static Application inst;
	

	
	public static Application getInstance() {
        return inst;
    }
	
	@Override
	public void start(Stage primaryStage) throws IOException {
		
		inst = this;
		BackLogic.getResource().setLogger(new Logger("log.txt", ""));
		

		Parent root = FXMLLoader.load(getClass().getResource("/resources/Scene.fxml"));

		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/resources/style.css").toExternalForm());

		primaryStage.setTitle("BitDetector");
		primaryStage.setResizable(false);
		Image icon = new Image(BitDetector.class.getResourceAsStream("/resources/icon.png"));
		primaryStage.getIcons().add(icon);
		primaryStage.setScene(scene);
		primaryStage.setOnCloseRequest(event -> stop(primaryStage));
		primaryStage.show();
	}

	
	private void stop(Stage stage) {
		BackLogic.getResource().closeLoger();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
}