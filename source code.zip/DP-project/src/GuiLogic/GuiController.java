package GuiLogic;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;

import javax.swing.plaf.DesktopIconUI;

import java.awt.*;
import backEnd.Address;
import backEnd.BackLogic;
import backEnd.BuildAddressObject;
import bitDetector.BitDetector;

public class GuiController {

	private static BackLogic backEnd = BackLogic.getResource();

	@FXML
	private TextField address2Add;

	@FXML
	private ImageView uploadButton;

	@FXML
	private Button ScanButton;

	@FXML
	private TableView<Address> tableScan;

	@FXML
	private TableColumn<Address, String> addressScan;

	@FXML
	private TableColumn<Address, Address> changeScan;

	@FXML
	private TableColumn<Address, Address> removeScan;

	@FXML
	private TableView<Address> tableReport;

	@FXML
	private TableColumn<Address, String> addressReport;

	@FXML
	private TableColumn<Address, Address> linkReport;

	@FXML
	private TableColumn<Address, Integer> reportsReport;

	@FXML
	private Button addToList;

	@FXML
	private Button clearTable;

	@FXML
	private Label Title;

	@FXML
	private AnchorPane pane;
	
	@FXML
	private TextArea logBox;

	@FXML
	public void add2List() {
		String addr = address2Add.getText();
		Address adrsObj;
		if ((adrsObj = BackLogic.getResource().saveToAddrList(addr)) != null) {
			tableScan.getItems().add(adrsObj);
			BackLogic.getResource().getLogger().log("added to scan table");
		}
		address2Add.clear();
		
	}

	@FXML
	public void clearScan() {
		System.out.println("clearScan");
		tableScan.getItems().clear();
		BackLogic.getResource().removeAll();
		BackLogic.getResource().getLogger().log("cleared table");
	}

	@FXML
	public void scanPress() {
		BackLogic.getResource().getLogger().log("scan addresses");
		tableReport.getItems().clear();
		BackLogic.getResource().scanTable();
		Iterator<Address> iter = BackLogic.getResource().addrListIterator();
		Address addr;
		while (iter.hasNext()) {
			addr = iter.next();
			tableReport.getItems().add(addr);
		}
		
	}

	@FXML
	public void uploadFile() {
		final FileChooser fileChooser = new FileChooser();
		
		tableScan.getItems().clear();
		BackLogic.getResource().removeAll();
		Scene s = pane.getScene();
		Stage stage = (Stage) s.getWindow();
		File f = fileChooser.showOpenDialog(stage);
		BufferedReader buffer;
		Address addr;
		if (f != null) {
			try {
				buffer = new BufferedReader(new FileReader(f));

				String str;
				while ((str = buffer.readLine()) != null) {
					addr = BackLogic.getResource().saveToAddrList(str);
					tableScan.getItems().add(addr);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			BackLogic.getResource().getLogger().log("upload file");
		}
	}
	
	@FXML
	public void saveResults() {
		final FileChooser fileChooser = new FileChooser();
		Scene s = pane.getScene();
		Stage stage = (Stage) s.getWindow();
		File f = fileChooser.showSaveDialog(stage);
		if (f == null) {
			return;
		}
		BackLogic.getResource().saveResults(f);
		BackLogic.getResource().getLogger().log("saved results");
	}

	@FXML
	public void initialize() {
		System.out.println("init");

		addressScan.setCellValueFactory(new PropertyValueFactory<Address, String>("address"));
		changeScan.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue()));
		changeScan.setCellFactory(param -> new TableCell<Address, Address>() {
			private final Button changeButton = new Button("change");

			@Override
			protected void updateItem(Address address, boolean empty) {
				super.updateItem(address, empty);

				if (address == null) {
					setGraphic(null);
					return;
				}

				setGraphic(changeButton);
				changeButton.setOnAction(event -> {
					
					TextInputDialog dialog = new TextInputDialog("Address");
					dialog.setTitle("change Address");
					dialog.setContentText("Please enter the new address:");
					Optional<String> result = dialog.showAndWait();
					result.ifPresent(_address -> {
						if (backEnd.contains(new Address(_address, null, 0))) {
							BackLogic.getResource().removeAddr(this.getItem());
							tableScan.getItems().remove(this.getItem());
						} else {
							this.getItem().setAddress(_address);
							tableScan.getItems().set(this.getIndex(), this.getItem());
						}
						BackLogic.getResource().getLogger().log("change address");
					});

				});
			}
		});

		removeScan.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue()));
		removeScan.setCellFactory(param -> new TableCell<Address, Address>() {
			private final Button removeButton = new Button("remove");

			@Override
			protected void updateItem(Address address, boolean empty) {
				super.updateItem(address, empty);

				if (address == null) {
					setGraphic(null);
					return;
				}

				setGraphic(removeButton);
				removeButton.setOnAction(event -> {
					Address addr = this.getItem();
					tableScan.getItems().remove(addr);
					BackLogic.getResource().removeAddr(addr);
					BackLogic.getResource().getLogger().log("removed address");

				});
			}
		});

		addressReport.setCellValueFactory(new PropertyValueFactory<Address, String>("address"));
		reportsReport.setCellValueFactory(new PropertyValueFactory<Address, Integer>("reports"));
		linkReport.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue()));
		linkReport.setCellFactory(param -> new TableCell<Address, Address>() {
			private final Hyperlink hyperlink = new Hyperlink("link");
			
			@Override
			protected void updateItem(Address address, boolean empty) {
				super.updateItem(address, empty);
				if (address == null) {
					setGraphic(null);
					return;
				}

				hyperlink.setText(address.getLink());
				setGraphic(hyperlink);
				hyperlink.setOnAction(event -> {				
					BitDetector.getInstance().getHostServices().showDocument(address.getLink());
				});
			}
		});
		
		BackLogic.getResource().getLogger().setLogBox(logBox);
		BackLogic.getResource().getLogger().log("intialize.. ");
		

	}
	


}
